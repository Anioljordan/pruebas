<?php
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
  echo json_encode([
    "success" => false,
    "message" => "Método no permitido."
  ]);
  exit;
}

// Honeypot anti-spam
if (!empty($_POST["website"])) {
  echo json_encode([
    "success" => false,
    "message" => "Solicitud bloqueada."
  ]);
  exit;
}

$name = trim($_POST["name"] ?? "");
$email = trim($_POST["email"] ?? "");
$message = trim($_POST["message"] ?? "");

if ($name === "" || $email === "" || $message === "") {
  echo json_encode([
    "success" => false,
    "message" => "Por favor, rellena todos los campos."
  ]);
  exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
  echo json_encode([
    "success" => false,
    "message" => "El correo electrónico no es válido."
  ]);
  exit;
}

$to = "info@barzemnuviladecavalls.com";
$subject = "Nuevo mensaje desde la web de Bar ZEMNU";

$cleanName = htmlspecialchars($name, ENT_QUOTES, "UTF-8");
$cleanEmail = htmlspecialchars($email, ENT_QUOTES, "UTF-8");
$cleanMessage = htmlspecialchars($message, ENT_QUOTES, "UTF-8");

$emailBody = "
Has recibido un nuevo mensaje desde la web de Bar ZEMNU.

Nombre:
$cleanName

Correo:
$cleanEmail

Mensaje:
$cleanMessage
";

$headers = "From: Bar ZEMNU <info@barzemnuviladecavalls.com>\r\n";
$headers .= "Reply-To: $cleanEmail\r\n";
$headers .= "Content-Type: text/plain; charset=UTF-8\r\n";

$sent = mail($to, $subject, $emailBody, $headers);

if ($sent) {
  echo json_encode([
    "success" => true,
    "message" => "Mensaje enviado correctamente. Te responderemos pronto."
  ]);
} else {
  echo json_encode([
    "success" => false,
    "message" => "No se ha podido enviar el mensaje. Inténtalo más tarde."
  ]);
}
?>